from pathlib import Path

# useful to access files by path.
PROJECT_ROOT_DIR = Path(__file__).parents[1]
SCRAPER_DIR = Path(__file__).parent
